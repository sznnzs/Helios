import pandas as pd
import os
import numpy as np


def binary_bit_count_list(numbers):
    # 对输入列表中的每个数字进行处理
    bit_counts = []
    for n in numbers:
        # 取整数部分
        integer_part = int(n)
        
        # 将整数部分转为二进制字符串并去掉前缀 "0b"
        binary_representation = bin(integer_part)[2:]
        
        # 计算二进制位数并将其添加到结果列表中
        bit_count = len(binary_representation)
        bit_counts.append(bit_count)
    return bit_counts

file_list = ["server1.csv","server2.csv",]
attack_list = ['BENIGN','DDoS-LOIC-HTTP' ,'DDoS-HOIC','DDoS-LOIC-UDP', \
               'DoS GoldenEye', 'DoS Hulk','DoS Slowloris' ,\
                'SSH-BruteForce','Web Attack - XSS','Web Attack - SQL','Web Attack - Brute Force'] 
 
# Note that should not bigger than 65535, because tofino swith can't deploy.
CUSTOM_FEAT_COLS = ['Protocol','Total Bwd packets' ,
'Fwd Packet Length Max', 'Fwd Packet Length Min','Fwd Packet Length Mean',
'Bwd Packet Length Max', 'Bwd Packet Length Min', 'Bwd Packet Length Mean',
]

dataset_X = []
dataset_y = []

CUSTOM_LABEL_COL = 'Label'
for csv_file in file_list:
    df = pd.read_csv(os.path.join('./CSE-CICIDS-2018-improved', f'{csv_file}'))

    df = df[df['Label'].isin(attack_list)]

    data = df[CUSTOM_FEAT_COLS].to_numpy()
    label = df[CUSTOM_LABEL_COL].to_numpy()
    dataset_X.append(data)
    dataset_y.append(label)
data_X = np.concatenate(dataset_X)
data_y = np.concatenate(dataset_y)

a, b = np.unique(data_y,return_counts=True)
print(a,b)

label_to_index = {label: index for index, label in enumerate(attack_list)}

data_y = np.array([label_to_index[label] for label in data_y])

a, b = np.unique(data_y,return_counts=True)
print(a,b)


np.save('./CICIDS_2018_X.npy', data_X)
np.save('./CICIDS_2018_y.npy', data_y)

